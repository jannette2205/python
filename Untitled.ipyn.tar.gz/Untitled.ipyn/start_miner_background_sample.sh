#!/bin/sh
nohup ./start_mining_yenten.sh  &
